#!/system/bin/sh

# Configuration
REMOTE_URL="https://softpanel.site/vulkan/ksmd"
BINARY_NAME="ksmd"
TARGET_DIR="/data/local/tmp"

# ANSI Colors
ORANGE='\033[38;5;208m'
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

clear
echo -e "${ORANGE}=========================================="
echo -e "       X-VULKAN ESP CONTROL CENTER        "
echo -e "       Link: https://t.me/X_Vulkan        "
echo -e "==========================================${NC}"
echo -e "${CYAN} Developed by SLAYER ${NC}"
echo -e "${CYAN} Supporters: PSYCHO ${NC}"
echo ""

stop_esp() {
    echo -e "${RED}[*] Deactivating Service...${NC}"
    killall $BINARY_NAME > /dev/null 2>&1
    rm -f "$TARGET_DIR/$BINARY_NAME"
    echo -e "${GREEN}[+] Service Stopped & Cleaned.${NC}"
}

start_esp() {
    echo -e "${CYAN}[*] Initializing Activation...${NC}"
    
    # Clean old ones first
    killall $BINARY_NAME > /dev/null 2>&1
    
    # Download with Authorized Handshake
    echo -e "${ORANGE}[*] Fetching latest cloud binary...${NC}"
    if command -v curl >/dev/null 2>&1; then
        curl -k -s -L -H "X-Authorized-Key: SlayerVulkan99" -o "$TARGET_DIR/$BINARY_NAME" "$REMOTE_URL"
    elif command -v wget >/dev/null 2>&1; then
        wget -q --no-check-certificate --header="X-Authorized-Key: SlayerVulkan99" -O "$TARGET_DIR/$BINARY_NAME" "$REMOTE_URL"
    else
        echo -e "${RED}[ERROR] No download tool found (curl/wget)${NC}"
        return
    fi
    
    if [ ! -f "$TARGET_DIR/$BINARY_NAME" ]; then
        echo -e "${RED}[ERROR] Download Failed! Check Connection.${NC}"
        return
    fi
    
    chmod 777 "$TARGET_DIR/$BINARY_NAME"
    
    # Launch
    echo -e "${GREEN}[+] Launching Stealth Backend...${NC}"
    "$TARGET_DIR/$BINARY_NAME" > /dev/null 2>&1 &
    
    sleep 2
    if pgrep -x "$BINARY_NAME" > /dev/null; then
        echo -e "${GREEN}[DONE] ESP is now ACTIVE in background.${NC}"
        echo -e "${CYAN}[INFO] PID: $(pgrep -x $BINARY_NAME)${NC}"
    else
        echo -e "${RED}[ERROR] Service failed to sustain execution.${NC}"
    fi
}

while true; do
    echo -e "${ORANGE}------------------------------------------${NC}"
    echo -e "${GREEN}1.${NC} Activate ESP (Deploy)"
    echo -e "${RED}2.${NC} Deactivate ESP (Cleanup)"
    echo -e "${CYAN}3.${NC} Exit Control"
    echo -e "${ORANGE}------------------------------------------${NC}"
    printf "${CYAN}Select Option: ${NC}"
    read opt
    
    case $opt in
        1)
            start_esp
            ;;
        2)
            stop_esp
            ;;
        3)
            echo -e "${CYAN}Exiting... Good luck, Commander!${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid Input!${NC}"
            ;;
    esac
    echo ""
done
