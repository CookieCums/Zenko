#!/system/bin/sh

# Launch PUBG Mobile
am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity

# Wait for 1 second
sleep 1

# Kill the app
am force-stop com.pubg.imobile