#!/system/bin/sh

PKG="com.instagram.android"

# Launch Instagram (safe method)
monkey -p $PKG -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1

# Wait 1 second
sleep 99999

# Kill it
am force-stop $PKG