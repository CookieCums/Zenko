#!/system/bin/sh

FOLDER="Zenko_Prefs"
DEST="/storage/emulated/0/"

# Root check
if [ "$(id -u)" != "0" ]; then
    echo "[ERROR] Run as root"
    exit 1
fi

if [ ! -d "./$FOLDER" ]; then
    echo "[ERROR] Folder not found: $FOLDER"
    exit 1
fi

echo "[INFO] Copying $FOLDER to $DEST"

mkdir -p "$DEST"

cp -rf "./$FOLDER" "$DEST"

if [ $? -eq 0 ]; then
    echo "[SUCCESS] Copied successfully"
else
    echo "[ERROR] Copy failed"
    exit 1
fi